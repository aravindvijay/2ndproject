package com.niit.collabrationB.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.remoting.soap.SoapFaultException;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.collabrationB.model.Blog;
import com.niit.collabrationB.model.Forum;
import com.niit.collabrationB.model.User;



@Configuration
@ComponentScan("com.niit.collabrationB")
@EnableTransactionManagement
public class Applicationcontextconfig {
	

		
		@Bean(name ="datasource")
		public DataSource getDataSource (){
			DriverManagerDataSource dataSource = new DriverManagerDataSource ();
			dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
			dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:orcl");
			dataSource.setUsername("system");
			dataSource.setPassword("Oracle#123");
			return dataSource;
		}

	 private Properties getHibernateProperties (){
		Properties properties = new Properties ();
	    properties.put("hibernate.show_sql","true");
	    properties.put("hibernate.dialect","org.hibernate.dialect.Oracle10gDialect");
	    System.out.println("database connected");
	    return properties;
	 }
	   @Autowired
		 @Bean(name = "transactionManager")
		 public HibernateTransactionManager getTransactionManager(
				 SessionFactory sessionFactory) {
		   HibernateTransactionManager transactionManager=new HibernateTransactionManager(sessionFactory);
		   System.out.println("Transaction...");
			return transactionManager;
		}
		   
		   @Autowired
			@Bean(name="sessionFactory")
			public SessionFactory getSessionFactory(DataSource dataSource){
				LocalSessionFactoryBuilder sessionBuilder=new LocalSessionFactoryBuilder(dataSource);
				 sessionBuilder.addProperties(getHibernateProperties());
				 sessionBuilder.addAnnotatedClass(User.class);
				 sessionBuilder.addAnnotatedClass(Blog.class);
				 sessionBuilder.addAnnotatedClass(Forum.class);
				 System.out.println("connected");
				 return sessionBuilder.buildSessionFactory();
				 
}
}