package com.niit.collabrationB.DAOImpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collabrationB.DAO.ForumDAO;
import com.niit.collabrationB.model.Blog;
import com.niit.collabrationB.model.Forum;

@Repository("forumDAO")
public class ForumDAOImpl implements ForumDAO{
	
	@Autowired
	private SessionFactory sessionFactory;

	public ForumDAOImpl(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public List<Forum> list() {
		@SuppressWarnings("unchecked")
		List<Forum> listForum = (List<Forum>)
		sessionFactory.getCurrentSession().createCriteria(Forum.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listForum;
		
		
	}
	@Transactional
	public Forum get(int id) {
		String hql = "from Forum where id" + id;
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings("unchecked")
		List<Forum> list = (List<Forum>) query.list();
		
		if(list!=null &&!(list.isEmpty()))
		{
			return list.get(0);
		}
		
		
		return null;
	}
	@Transactional
	public void saveOrUpdate(Forum forum) {
		sessionFactory.getCurrentSession().saveOrUpdate(forum);
		
	}
	@Transactional
	public void delete(int id) {
		Forum forumToDelete = new Forum();
		forumToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(forumToDelete);
		
	}

}
