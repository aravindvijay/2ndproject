package com.niit.collabrationB.DAO;

import java.util.List;

import com.niit.collabrationB.model.Forum;



public interface ForumDAO {

	public List<Forum> list();
	public Forum get(int id);
	
	public void saveOrUpdate(Forum forum);
	public void delete(int id);
	
	
}
