package com.niit.collabrationB.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collabrationB.DAO.UserDAO;
import com.niit.collabrationB.model.User;

public class UserTest {

	public static void main(String[] args) {
	      AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
			
			context.scan("com.niit.collabrationB");
			context.refresh();
			
			UserDAO userDAO = (UserDAO) context.getBean("userDAO");
			User user = (User) context.getBean("user");
			//user.setId(1);
			user.setUsername("vijjnbjbjbay");
			user.setPassword("1224");
			user.setAddress("i2jk");
			user.setEmail("vij2y@gmail");
			user.setEnable("T");
			user.setRole("ROLE_ADMIN");
			
			userDAO.saveOrUpdate(user);
			
			
}
}