package com.niit.collabrationB.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collabrationB.DAO.BlogDAO;
import com.niit.collabrationB.DAO.UserDAO;
import com.niit.collabrationB.model.Blog;
import com.niit.collabrationB.model.User;

public class BlogTest {

	public static void main(String[] args) {
	      AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
			
			context.scan("com.niit.collabrationB");
			context.refresh();
			
			BlogDAO blogDAO = (BlogDAO) context.getBean("blogDAO");
			Blog blog = (Blog) context.getBean("blog");
			//user.setId(1);
			
		blog.setDescription("supper");
		blog.setTopic("chat");
		blog.setTitle("mess");
		blog.setName("hj");
	
		blogDAO.saveOrUpdate(blog);
}
}