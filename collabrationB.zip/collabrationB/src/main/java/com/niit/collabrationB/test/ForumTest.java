package com.niit.collabrationB.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.collabrationB.DAO.ForumDAO;

import com.niit.collabrationB.model.Forum;

public class ForumTest {

	public static void main(String[] args) {
	      AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
			
			context.scan("com.niit.collabrationB");
			context.refresh();
			
			ForumDAO forumDAO = (ForumDAO) context.getBean("forumDAO");
			Forum forum = (Forum) context.getBean("forum");
			
			forum.setDescription("nyc");
			forum.setTopic("jh");
			forum.setTitle("bam");
			forum.setName("fsdd");
		
			forumDAO.saveOrUpdate(forum);
}
}